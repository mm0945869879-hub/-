#!/usr/bin/env bash
set -e
npm install
rm -rf www && mkdir www
# KaTeX محلياً ليعمل التطبيق دون إنترنت
cp node_modules/katex/dist/katex.min.js www/katex.min.js
# الصفحة الرئيسية = index.html ، والمنصة التفاعلية = app.html
sed 's#https://claude.ai/artifact/AaWHiLmXH2RXk4GFUJ5y2J#app.html#; s# target="_blank" rel="noopener"##' src/home.html > www/index.html
sed 's#https://cdnjs.cloudflare.com/ajax/libs/KaTeX/0.16.9/katex.min.js#katex.min.js#' src/app.html > www/app.html
[ -d android ] || npx cap add android
# منع لقطة الشاشة وتسجيلها داخل التطبيق (FLAG_SECURE)
J=android/app/src/main/java/com/hamada/physics/MainActivity.java
cat > $J <<'JAVA'
package com.hamada.physics;
import android.os.Bundle;
import android.view.WindowManager;
import com.getcapacitor.BridgeActivity;
public class MainActivity extends BridgeActivity {
  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);
  }
}
JAVA
npx cap sync android
cd android && chmod +x gradlew && ./gradlew assembleDebug
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
